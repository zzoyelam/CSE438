//
//  watchVC.swift
//  
//
//  Created by Zayid Oyelami on 7/19/19.
// Data scraped from tmdb.org

import UIKit
import AVKit
class watchVC: AVPlayerViewController {
    var vURL : URL?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
        let player = AVPlayer(url: vURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        
        present(playerViewController, animated: true) {
            player.play()
        }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
