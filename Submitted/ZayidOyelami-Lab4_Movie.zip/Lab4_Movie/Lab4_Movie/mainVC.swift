//
//  FirstViewController.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/17/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//
// Data scraped from tmdb.org
import UIKit

class mainVC: UICollectionViewController, UISearchBarDelegate {
    let dataSource = movieDataStream()
    let imgCache = ImageCache()
    let searchController = UISearchController(searchResultsController: nil)
    func searchBarIsEmpty() -> Bool {
        // Returns true if the text is empty or nil
        return searchController.searchBar.text?.isEmpty ?? true
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        print(self.searchController.searchBar)
        //        self.searchController.searchBar.pre
    }
    lazy var refreshControl: UIRefreshControl = {
       let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(startLoading), for: .valueChanged)
        return refresh
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup the Search Controller
        startLoading()
        self.collectionView?.addSubview(refreshControl)

}
    @objc func startLoading(){
        dataSource.fetch(completion:{(error) in
            self.stopLoading()
            self.collectionView?.reloadData()
        })
        
    }
    
    func stopLoading(){
        dataSource.fetch(completion:{(error) in
            self.collectionView?.reloadData()
        })
        refreshControl.endRefreshing()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destNav = segue.destination as? UINavigationController
        let dest = destNav?.topViewController as? detailVC
        let indexPath = collectionView?.indexPathsForSelectedItems?.first
        dest!.configureForPhoto(movie: dataSource.movies[indexPath!.item], imageCache: imgCache)
    }
}

extension mainVC: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let artworkSize = CGSize(width: 133, height: 200)
        let count = trunc(collectionView.frame.width / artworkSize.width) + 1
        let width = collectionView.frame.width / count
        let aspect = artworkSize.width / artworkSize.height
        return CGSize(width: width, height: width / aspect)
    }

}

extension mainVC {
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCell", for: indexPath) as? movieCell {
            let movie = dataSource.movies[indexPath.item]
            cell.configure(with: movie, imageCache: imgCache)
            return cell
        } else {
            return UICollectionViewCell()
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataSource.movies.count
    }
}
