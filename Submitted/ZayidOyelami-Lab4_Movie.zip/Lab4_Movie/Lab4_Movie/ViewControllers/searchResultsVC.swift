//
//  FirstViewController.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/17/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
// Data scraped from tmdb.org

import UIKit

class searchResultsVC: UICollectionViewController,UISearchBarDelegate {
    let dataSource = movieDataStreamQuery()
    let imgCache = ImageCache()
    let searchController = UISearchController(searchResultsController: nil)
    let activityView = UIActivityIndicatorView(style: .whiteLarge)
    
    func searchBarIsEmpty() -> Bool {
        // Returns true if the text is empty or nil
        return searchController.searchBar.text?.isEmpty ?? true
    }
    let activityIndicatorView = UIActivityIndicatorView(style: .whiteLarge)
    func startLoading(){
        self.collectionView?.addSubview(activityIndicatorView)
        activityIndicatorView.backgroundColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.7)
        activityIndicatorView.center = self.collectionView.center
        activityIndicatorView.frame = self.collectionView.frame
        activityIndicatorView.startAnimating()
    }
    func stopLoading(){
        self.collectionView?.reloadData()
        activityIndicatorView.stopAnimating()
    }
    
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        self.startLoading()
        dataSource.fetchQuery(query:searchText,completion:{(error) in
            self.stopLoading()
        })
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup the Search Controller
        searchController.searchBar.delegate = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Movies"
        // Adding search bar to Navigation Item
        navigationItem.searchController = searchController
        // Will only be active on the current screen
        definesPresentationContext = true
        navigationItem.hidesSearchBarWhenScrolling = false
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Looking..")
        refreshControl.backgroundColor = UIColor(red:0.5, green:0.5, blue:0.5, alpha:0.3)
        refreshControl.tintColor = UIColor.white
        refreshControl.addTarget(self, action: #selector(searchBarSearchButtonClicked(_:)), for: .valueChanged)
        self.collectionView.backgroundView?.addSubview(refreshControl)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destNav = segue.destination as? UINavigationController
        let dest = destNav?.topViewController as? detailVC
        let indexPath = collectionView?.indexPathsForSelectedItems?.first
        print(dataSource.movies[indexPath!.item])
        dest!.configureForPhoto(movie: dataSource.movies[indexPath!.item], imageCache: imgCache)
    }
//    lazy var refreshControl: UIRefreshControl = {
//        let refresh = UIRefreshControl()
//        refresh.addTarget(self, action: #selector(searchBarSearchButtonClicked(_:)), for: .valueChanged)
//        return refresh
//    }()
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        filterContentForSearchText(searchBar.text!)
    }
}

extension searchResultsVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let artworkSize = CGSize(width: 133, height: 200)
        let count = trunc(collectionView.frame.width / artworkSize.width) + 1
        let width = collectionView.frame.width / count
        let aspect = artworkSize.width / artworkSize.height
        return CGSize(width: width, height: width / aspect)
    }
    
}

extension searchResultsVC {
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCell", for: indexPath) as? movieCell {
            let movie = dataSource.movies[indexPath.item]
            cell.configure(with: movie, imageCache: imgCache)
            return cell
           
            
        } else {
            return UICollectionViewCell()
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //        if let dataSource = dataSource {
        //            return dataSource?.movies.count
        //        } else {
        //            return 0
        //        }
        return dataSource.movies.count
    }
}
