//
//  movieSearchResults.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/12/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import UIKit
import Foundation

struct movieSearchResults:Decodable {
    let page: Int
    let total_results: Int
    let total_pages: Int
    let results: [movieItem]
}
struct movieItem: Decodable {
    let id: Int!
    let poster_path: String?
    let title: String
    let release_date: String
    let vote_average: Double
    let overview: String
    let vote_count:Int!
    let backdrop_path: String?
//    let genre_ids = [genres]
    
    
    init (id: Int!, poster_path: String?, title: String, release_date: String,vote_average:Double,overview:String,vote_count:Int!,backdrop_path:String?) {
        self.id = id
        self.poster_path = poster_path
        self.title = title
        self.release_date = release_date
        self.vote_average = vote_average
        self.overview = overview
        self.vote_count = vote_count
        self.backdrop_path = backdrop_path
    }
}

struct videoResults: Decodable {
    let id: Int
    let results: [video]
}

struct video: Decodable {
    let key: String
    
    init (key: String) {
        self.key = key
    }
}
