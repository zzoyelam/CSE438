//
//  detailVC.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/17/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
// Data scraped from tmdb.org

import UIKit
import CoreData
import AVKit
import WebKit

class detailVC: UITableViewController {
var Favorites: [NSManagedObject] = []
    var videoList: videoResults?

    @IBAction func addToFavs(_ sender: Any) {
        save(title:movie!.title)
        let vc = storyboard?.instantiateViewController(withIdentifier: "favoritesVC") as! favoritesVC
        vc.Favorites = Favorites
        print(Favorites)
        vc.tableView.reloadData()
    }
    
    @IBOutlet weak var webView: WKWebView!
    @IBAction func watchTrailer(_ sender: Any) {
        if let vList = videoList{
            if !vList.results.isEmpty{
            let vUrl = vList.results[0].key
            let videoURL = URL(string: "https://www.youtube.com/embed/\(vUrl)")
            let youtubeURL = videoURL
            webView.load(URLRequest(url: videoURL!))
        }
            else{
                let alertController = UIAlertController(title: "Trailer Unavailable", message: "Sorry, we don't have this one :(", preferredStyle: .alert)
                //We add buttons to the alert controller by creating UIAlertActions:
                let actionOk = UIAlertAction(title: "OK",
                                             style: .default,
                                             handler: nil) //You can use a block here to handle a press on this button
                
                alertController.addAction(actionOk)
                
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
    }
    
    
    private(set) var movie: movieItem?
    private(set) var imageCache: ImageCache?
    
    @IBAction func addFav(_ sender: Any) {
        
    }
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var titleCell: UITableViewCell!

    @IBOutlet weak var scoreCell: UITableViewCell!
    @IBOutlet weak var releaseDateCell: UITableViewCell!
    @IBOutlet weak var numVoters: UITableViewCell!
    
    @IBOutlet weak var moreCell: UITableViewCell!
    @IBOutlet weak var descriptionCell: UITextView!
    func configureForPhoto(movie: movieItem, imageCache: ImageCache) {
        self.movie = movie
        self.imageCache = imageCache
    }

    func save(title: String) {
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        // 2
        let entity =
            NSEntityDescription.entity(forEntityName: "Favorites",
                                       in: managedContext)!
        
        let favorite = NSManagedObject(entity: entity,
                                     insertInto: managedContext)
        
        // 3
        favorite.setValue(title, forKeyPath: "title")
        
        // 4
        do {
            try managedContext.save()
            Favorites.append(favorite)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "InputVCToDisplayVC"){
            let destVC = segue.destination as! watchVC
//            print(URL(string: "https://www.youtube.com/watch?v=\(videoList!.results[0].key)"))
                        destVC.vURL = URL(string: "https://www.youtube.com/watch?v=\(videoList!.results[0].key)")
        }}

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let apiKey = "fe3e3e42357e1379d294696ea66c3376"
        let baseURL = "https://image.tmdb.org/t/p/w200/"
        let baseURL500 = "https://image.tmdb.org/t/p/w500/"
        
        if let movie = movie, let imageCache = imageCache {
            let baseYouTube = URL(string: "https://api.themoviedb.org/3/movie/\((movie.id)!)/videos?api_key=\(apiKey)")
            title = movie.title
            titleCell?.detailTextLabel?.text = movie.title
            scoreCell?.detailTextLabel?.text = String(movie.vote_average)
            releaseDateCell?.detailTextLabel?.text = movie.release_date
            numVoters?.detailTextLabel?.text = String(movie.vote_count)
            descriptionCell?.text = movie.overview
            
            if let imgPath = movie.poster_path{
                imageCache.image(with: URL(string: baseURL + "\(movie.poster_path!)")!) { (_, image, _) in
                    self.imgView?.image = image
                }
            }
            else{
                self.imgView?.image = UIImage(imageLiteralResourceName: "tmdb.png")
            }
            
            if let imgPath = movie.backdrop_path{
                imageCache.image(with: URL(string: baseURL500 + "\(imgPath)")!) { (url, image, error) in
                    if let image = image, url == URL(string:baseURL500+"\((self.movie?.backdrop_path)!)") {
                        
    
                        UIGraphicsBeginImageContext(self.imgView.frame.size)
                        image.draw(in: self.imgView.bounds)
                        let image2: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
                        UIGraphicsEndImageContext()
                        
                        self.imgView.backgroundColor = UIColor(patternImage: image2)
                        
                        
                        
                    }
                }
            }
            if let youtubePath = baseYouTube{
                let urlSession = URLSession.shared
                urlSession.dataTask(with: youtubePath){(data,response,err)
                    in
        
                    guard let data = data else {return}
                    do {
                        
                        self.videoList = try JSONDecoder().decode(videoResults.self, from: data)
//                        print("https://www.youtube.com/watch?v=\(videoList.results[0].key)")
                    }
                    catch {

                    }

                    }.resume()
                
                
 
                    }
                }
            }
        }
        

    
    


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation




