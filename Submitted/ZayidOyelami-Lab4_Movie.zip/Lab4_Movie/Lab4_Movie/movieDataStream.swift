//
//  movieDataStream.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/12/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import Foundation

// Return errors for json and other errors
enum movieDataStreamError: Error {
    case jsonError, unknownError
}

protocol movieDataStreamProtocol {
    var movies: [movieItem]{ get }
    // Asychronous fetch movie search results
    func fetch(completion: @escaping (Error?) -> Void)
}

class movieDataStream: movieDataStreamProtocol {
    
    // Empty array for movies
    private(set) var movies: [movieItem] = [movieItem]()
    // Constructing url to grab data for the most popular movies
        let urlSession = URLSession.shared
        let apiKey = "fe3e3e42357e1379d294696ea66c3376"
        let adultBool = "false"
        let pageNum = 1
        var apiURL: URLComponents {
            var apiURL = URLComponents()
            apiURL.scheme = "https"
            apiURL.host = "api.themoviedb.org"
            apiURL.path = "/3/discover/movie"
            apiURL.queryItems = [
                URLQueryItem(name: "api_key", value: apiKey),
                URLQueryItem(name: "language", value: "en-US"),
                URLQueryItem(name: "sort_by", value: "popularity.desc"),
                URLQueryItem(name: "include_adult", value: adultBool),
                URLQueryItem(name: "page", value: String(pageNum))
            ]
            return apiURL
        }
    
    

    func fetch(completion: @escaping (Error?) -> Void) {
        urlSession.dataTask(with: apiURL.url!){(data,response,err)
            in
            // check err and response status
            guard let data = data else { return}
            
            do {
                let movieResults = try JSONDecoder().decode(movieSearchResults.self, from: data)
                DispatchQueue.main.async {
                    self.movies = movieResults.results
                    completion(nil)
                }
            } catch{
                DispatchQueue.main.async {
                    completion(error)
                }
            }
            
            }.resume()
    }

    }
