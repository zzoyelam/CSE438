//
//  movieCell.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/12/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import UIKit
import Foundation
class movieCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView?
    @IBOutlet weak var movieLabel: UILabel!
    var movie: movieItem?
    let baseURL = "https://image.tmdb.org/t/p/w200/"

    func configure(with movie: movieItem, imageCache: ImageCache) {
        self.movie = movie
        movieLabel.text = movie.title
        if let imgPath = movie.poster_path{
            imageCache.image(with: URL(string: baseURL + "\(imgPath)")!) { (url, image, error) in
                if let image = image, url == URL(string:self.baseURL+"\((self.movie?.poster_path)!)") {
                    self.imageView?.image = image
                }
            }
        }
        else {
            self.imageView?.image = UIImage(imageLiteralResourceName: "tmdb.png")
        }

    }

    override func prepareForReuse() {
        super.prepareForReuse()
        imageView?.image = nil
        movie = nil
    }

}
