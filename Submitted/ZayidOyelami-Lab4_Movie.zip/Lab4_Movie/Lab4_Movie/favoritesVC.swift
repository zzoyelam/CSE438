//
//  SecondViewController.swift
//  Lab4_Movie
//
//  Created by Zayid Oyelami on 7/17/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
// Data scraped from tmdb.org

import UIKit
import CoreData

let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

class favoritesVC: UITableViewController {
    var Favorites : [NSManagedObject] = []
    
    @IBOutlet var favTable: UITableView!
    func save(){
        do{
            try context.save()
        }catch {
            print("Error saving item with \(error)")
        }
       tableView.reloadData()
    }

    func fetchData(){
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Favorites")
        
        //3
        do {
            Favorites = try managedContext.fetch(fetchRequest)
            self.tableView.reloadData()
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        save()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
    }

    

// MARK: - UITableViewDataSource
    override func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return Favorites.count
    }
    
    override func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath)
        -> UITableViewCell {
            
            let favorite = Favorites[indexPath.row]
            let cell =
                tableView.dequeueReusableCell(withIdentifier: "tableCell",
                                              for: indexPath)
            cell.textLabel?.text =
                favorite.value(forKeyPath: "title") as? String
            return cell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            let fav = Favorites[indexPath.row]
            Favorites.remove(at: indexPath.row)
            context.delete(fav)
            
            do {
                try context.save()
            } catch {
                print("Error deleting items with \(error)")
            }
            tableView.deleteRows(at: [indexPath], with: .automatic)  //includes updating
            
  
        }
    }
    

}

