//
//  AppDelegate.swift
//  Lab3_Drawing
//
//  Created by Zayid Oyelami on 7/3/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

}

