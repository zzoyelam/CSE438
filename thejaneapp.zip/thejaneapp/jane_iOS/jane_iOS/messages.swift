//
//  messages.swift
//  jane_iOS
//
//  Created by Zayid Oyelami on 7/23/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.

import Foundation
import CoreLocation
import AVFoundation
import UserNotifications
import MessageKit

struct MockLocationItem: LocationItem {
    
    var location: CLLocation
    var size: CGSize
    
    init(location: CLLocation) {
        self.location = location
        self.size = CGSize(width: 240, height: 240)
    }
    
}

struct MockMediaItem: MediaItem {
    
    var url: URL?
    var image: UIImage?
    var placeholderImage: UIImage
    var size: CGSize
    
    init(image: UIImage) {
        self.image = image
        self.size = CGSize(width: 240, height: 240)
        self.placeholderImage = UIImage()
    }
    
}

private struct MockAudiotem: AudioItem {
    
    var url: URL
    var size: CGSize
    var duration: Float
    
    init(url: URL, duration: Float) {
        self.url = url
        self.size = CGSize(width: 160, height: 35)
        self.duration = duration
    }
    
}

struct Member {
    let name: String
    let color: UIColor
    let image: UIImage
}

struct Message: MessageType {
    var user: Member
    var messageId: String
    var sender: SenderType {
        return Sender(senderId: user.name, displayName: user.name)
    }
    var sentDate: Date
    var kind: MessageKind
    
    
    private init(kind: MessageKind, user: Member, messageId: String) {
        self.kind = kind
        self.user = user
        self.messageId = messageId
        self.sentDate = Date()
    }
    
    init(text: String, user: Member, messageId: String) {
        self.init(kind: .text(text), user: user, messageId: messageId)
    }
    
    init(attributedText: NSAttributedString, user: Member, messageId: String) {
        self.init(kind: .attributedText(attributedText), user: user, messageId: messageId)
    }
    
    init(image: UIImage, user: Member, messageId: String) {
        let mediaItem = MockMediaItem(image: image)
        self.init(kind: .photo(mediaItem), user: user, messageId: messageId)
    }
    
    init(thumbnail: UIImage, user: Member, messageId: String) {
        let mediaItem = MockMediaItem(image: thumbnail)
        self.init(kind: .video(mediaItem), user: user, messageId: messageId)
    }
    
    init(location: CLLocation, user: Member, messageId: String) {
        let locationItem = MockLocationItem(location: location)
        self.init(kind: .location(locationItem), user: user, messageId: messageId)
    }
    
    init(emoji: String, user: Member, messageId: String) {
        self.init(kind: .emoji(emoji), user: user, messageId: messageId)
    }
    
    init(audioURL: URL, duration: Float, user: Member, messageId: String) {
        let audioItem = MockAudiotem(url: audioURL, duration: duration)
        self.init(kind: .audio(audioItem), user: user, messageId: messageId)
    }
    
}
