//
//  ViewController.swift
//  jane_iOS
//
//  Created by Zayid Oyelami on 7/24/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import UIKit
import MapKit
import Foundation
import Alamofire
import SwiftyJSON
import MessageKit
import InputBarAccessoryView
import Intents
import GoogleSignIn
import UserNotifications


class chatVC: MessagesViewController {

    var messages: [Message] = []
    var member: Member!
    var txt = ""
    private let locationNotificationScheduler = LocationNotificationScheduler()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationNotificationScheduler.delegate = self
        member = Member(name: "Zayid", color: .blue,image:UIImage(named: "me")!)
        messageInputBar.delegate = self
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        self.messagesCollectionView.contentInset = UIEdgeInsets(top: 44, left: 0, bottom: 0, right: 0)
        INPreferences.requestSiriAuthorization { (status) in
            if status == INSiriAuthorizationStatus.authorized {
                print("Sirikit authorized")
            }
            else {
                print("Sirikit unauthorized")
            }
        }
        donateIntent()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if #available(iOS 11.0, *) {
            navigationController?.navigationBar.prefersLargeTitles = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if #available(iOS 11.0, *) {
            navigationController?.navigationBar.prefersLargeTitles = false
        }
    }
    @objc func didTapSignOut() {
        GIDSignIn.sharedInstance().signOut()
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginScreen") as! UIViewController
        
        self.present(viewController, animated: true, completion: nil)

    }
    
    @objc func didSchedule() {
        let notificationInfo = LocationNotificationInfo(notificationId: "nyc_promenade_notification_id",
                                                        locationId: "nyc_promenade_location_id",
                                                        radius: 500.0,
                                                        latitude: 40.696503,
                                                        longitude: -73.997809,
                                                        title: "Welcome to the Brooklyn Promenade!",
                                                        body: "Tap to see more information",
                                                        data: ["location": "NYC Brooklyn Promenade"])
        print(notificationInfo)
        
        locationNotificationScheduler.requestNotification(with: notificationInfo)
    }
    override func viewDidLayoutSubviews() {
        
        func setUpNavBar() {
            let navBar = UINavigationBar(frame: CGRect(x: 0, y: 45, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height/8))
            self.view.addSubview(navBar)
            navBar.items?.append(UINavigationItem(title: "Capacity"))
            let backButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(didTapSignOut))
            let leftButton = UIBarButtonItem(title: "Schedule", style: .plain, target: self, action: #selector(didSchedule))
            navBar.topItem?.rightBarButtonItem = backButton
            navBar.topItem?.leftBarButtonItem = leftButton
        }
        setUpNavBar()
    }
    
    
    private func donateIntent(){
        INPreferences.requestSiriAuthorization{[weak self]
            (authorization) in
            guard let strongSelf = self else {return}
            guard authorization ==
                INSiriAuthorizationStatus.authorized else {
                    return
            }
            let intent = INSendMessageIntent()
            self?.txt = intent.content ?? ""
            print(self?.txt)
            intent.suggestedInvocationPhrase = "Ask Capacity"
            let interaction = INInteraction(intent: intent, response: nil)
            interaction.donate(completion: {(error) in
                if let error = error {
                    print(error.localizedDescription)
                }
            })
        }
    }
//

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func insertMessage(_ message: Message) {
        messages.append(message)
        self.messageInputBar.sendButton.stopAnimating()
        self.messageInputBar.inputTextView.placeholder = ""
        // Reload last section to update header/footer labels and insert a new one
        messagesCollectionView.performBatchUpdates({
            messagesCollectionView.insertSections([messages.count - 1])
            if messages.count >= 2 {
                messagesCollectionView.reloadSections([messages.count - 2])
            }
        }, completion: { [weak self] _ in
            if self?.isLastSectionVisible() == true {
                self?.messagesCollectionView.scrollToBottom(animated: true)
            }
        })
    }
    
    func isLastSectionVisible() -> Bool {
        
        guard !messages.isEmpty else { return false }
        
        let lastIndexPath = IndexPath(item: 0, section: messages.count - 1)
        
        return messagesCollectionView.indexPathsForVisibleItems.contains(lastIndexPath)
    }
    
    
    func configureMessageInputBar() {
        messageInputBar.delegate = self
        messageInputBar.inputTextView.tintColor = .primaryColor
        messageInputBar.sendButton.setTitleColor(.primaryColor, for: .normal)
        messageInputBar.sendButton.setTitleColor(
            UIColor.primaryColor.withAlphaComponent(0.3),
            for: .highlighted
        )
    }

}

// MESSAGE DATA SOURCE
extension chatVC: MessagesDataSource {
    
    func currentSender() -> SenderType {

        return Sender(senderId: member.name, displayName: member.name)
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return messages.count
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return messages[indexPath.section]
    }
    func messageTopLabelAttributedText(for message: MessageType, at indexPath: IndexPath) -> NSAttributedString? {
        let name = message.sender.displayName
        return NSAttributedString(string: name, attributes: [NSAttributedString.Key.font: UIFont.preferredFont(forTextStyle: .caption1)])
    }
    
    // 4
    func cellTopLabelAttributedText(for message: MessageType,
                                    at indexPath: IndexPath) -> NSAttributedString? {
        
        let name = message.sender.displayName
        return NSAttributedString(
            string: name,
            attributes: [
                .font: UIFont.preferredFont(forTextStyle: .caption1),
                .foregroundColor: UIColor(white: 0.3, alpha: 1)
            ]
        )
    }
}

// MARK: - MessagesLayoutDelegate

extension chatVC: MessagesLayoutDelegate {
    
    func avatarSize(for message: MessageType, at indexPath: IndexPath,
                    in messagesCollectionView: MessagesCollectionView) -> CGSize {
        
        // 1
        return .zero
    }
    
    func footerViewSize(for message: MessageType, at indexPath: IndexPath,
                        in messagesCollectionView: MessagesCollectionView) -> CGSize {
        
        // 2
        return CGSize(width: 0, height: 8)
    }
    
    func heightForLocation(message: MessageType, at indexPath: IndexPath,
                           with maxWidth: CGFloat, in messagesCollectionView: MessagesCollectionView) -> CGFloat {
        
        // 3
        return 0
    }
}
extension chatVC: MessagesDisplayDelegate {
    
    func backgroundColor(for message: MessageType, at indexPath: IndexPath,
                         in messagesCollectionView: MessagesCollectionView) -> UIColor {
        
        // 1
        return isFromCurrentSender(message: message) ? .primary : .incomingMessage
    }
    
    func shouldDisplayHeader(for message: MessageType, at indexPath: IndexPath,
                             in messagesCollectionView: MessagesCollectionView) -> Bool {
        
        // 2
        return true
    }
    
    func messageStyle(for message: MessageType, at indexPath: IndexPath,
                      in messagesCollectionView: MessagesCollectionView) -> MessageStyle {
        
        let corner: MessageStyle.TailCorner = isFromCurrentSender(message: message) ? .bottomRight : .bottomLeft
        
        // 3
        return .bubbleTail(corner, .curved)
    }
    
    func configureAvatarView(
        _ avatarView: AvatarView,
        for message: MessageType,
        at indexPath: IndexPath,
        in messagesCollectionView: MessagesCollectionView) {
        let message = messages[indexPath.section]
        let color = message.user.color
        avatarView.backgroundColor = UIColor(red:1.00, green:0.62, blue:0.00, alpha:1.0)
        avatarView.image = message.user.image
    }
}


extension chatVC: MessageInputBarDelegate {
    public func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String){
        let newMessage = Message(text: text, user: Member(name: "Zayid", color:.blue,image: UIImage(named: "me")!), messageId: UUID().uuidString)
                messages.append(newMessage)
                inputBar.inputTextView.text = ""
                txt = text
                let parameters: [String: Any] = ["inquiry": txt ]
                let url  = URL(string: "https://api-concierge.aisoftware.com/v1/process")
                var request = URLRequest(url: url!)
                request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
                request.addValue("Bearer 277b15da-ebd8-465f-a704-ab2128f58c4b", forHTTPHeaderField: "Authorization")
                request.httpMethod = "POST"
                request.httpBody = parameters.percentEscaped().data(using: .utf8)
                //create the session object
                let session = URLSession.shared
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")
                request.addValue("application/json", forHTTPHeaderField: "Accept")
        //create dataTask using the session object to send data to the server
                // Send button activity animation
                self.messageInputBar.sendButton.startAnimating()
                self.messageInputBar.inputTextView.placeholder = "Sending..."
        
                let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
                    
                    guard let data = data,
                        let response = response as? HTTPURLResponse,
                        error == nil else {                                              // check for fundamental networking error
                            print("error", error ?? "Unknown error")
                            return
                    }
                    
                    guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
                        print("statusCode should be 2xx, but is \(response.statusCode)")
                        print("response = \(response)")
                        return
                    }
                    
                    // Need to convert to Json
                    let json = try? JSON(data: data)
                    var resp = json!["data"]["data"]["outputs"][0][0]
                    
                    DispatchQueue.main.async {
//                        let responseMessage = Message(attributedText: (resp.string?.htmlToAttributedString)!, user: Member(name: "Capacity", color:.purple), messageId: UUID().uuidString)
                        let responseMessage = Message(text: (resp.string?.htmlToAttributedString?.string)!, user: Member(name: "Capacity", color:.purple,image:UIImage(named: "capacityLogo")!), messageId: UUID().uuidString)
                        self.insertMessage(responseMessage)
                    }
                    
                })
                task.resume()

        messagesCollectionView.reloadData()
        messagesCollectionView.scrollToBottom(animated: true)
        INInteraction(intent: AskCapacityIntent(), response: nil).donate(completion: nil)
        
    }
}

private extension Dictionary {
    func percentEscaped() -> String {
        return map { (key, value) in
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedKey + "=" + escapedValue
            }
            .joined(separator: "&")
    }
}

private extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
        let subDelimitersToEncode = "!$&'()*+,;="
        
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowed
    }()
}
private extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return NSAttributedString()
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
}

extension chatVC: LocationNotificationSchedulerDelegate {
    
    func locationPermissionDenied() {
        let message = "The location permission was not authorized. Please enable it in Settings to continue."
        presentSettingsAlert(message: message)
    }
    
    func notificationPermissionDenied() {
        let message = "The notification permission was not authorized. Please enable it in Settings to continue."
        presentSettingsAlert(message: message)
    }
    
    func notificationScheduled(error: Error?) {
        if let error = error {
            let alertController = UIAlertController(title: "Notification Schedule Error",
                                                    message: error.localizedDescription,
                                                    preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true)
        } else {
            let alertController = UIAlertController(title: "Notification Scheduled!",
                                                    message: "You will be notified when you are near the location!",
                                                    preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true)
        }
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        if response.notification.request.identifier == "nyc_promenade_notification_id" {
            let notificationData = response.notification.request.content.userInfo
            let message = "You have reached \(notificationData["location"] ?? "your location!")"
            
            let alertController = UIAlertController(title: "Welcome!",
                                                    message: message,
                                                    preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true)
        }
        completionHandler()
    }
    
    private func presentSettingsAlert(message: String) {
        let alertController = UIAlertController(title: "Permissions Denied!",
                                                message: message,
                                                preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let settingsAction = UIAlertAction(title: "Settings", style: .default) { (alertAction) in
            if let appSettings = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(appSettings)
            }
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(settingsAction)
        
        present(alertController, animated: true)
    }
}
