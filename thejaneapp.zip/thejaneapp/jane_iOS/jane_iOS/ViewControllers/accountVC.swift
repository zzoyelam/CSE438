//
//  AddToSiri.swift
//  capacity_iOS
//
//  Created by Zayid Oyelami on 7/30/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import UIKit
import Intents
import IntentsUI

class accountVC: UIViewController {

    let siriButton = INUIAddVoiceShortcutButton(style: .whiteOutline)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // neglect
        
        addSiriButton(to: view)
    }
    
    func addSiriButton(to view: UIView) {
        siriButton.translatesAutoresizingMaskIntoConstraints = false
        
        // Add Capacity intent to Siri button
        let intent = AskCapacityIntent()
        intent.suggestedInvocationPhrase = "\(intent.question)"
        siriButton.shortcut = INShortcut(intent: intent)
        
        // shortcut delegations
//        siriButton.delegate = self as! INUIAddVoiceShortcutButtonDelegate
        view.addSubview(siriButton)
        view.centerXAnchor.constraint(equalTo: siriButton.centerXAnchor).isActive = true
        view.centerYAnchor.constraint(equalTo: siriButton.centerYAnchor).isActive = true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
