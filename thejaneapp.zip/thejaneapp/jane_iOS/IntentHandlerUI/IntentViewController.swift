//
//  IntentViewController.swift
//  IntentHandlerUI
//
//  Created by Zayid Oyelami on 7/28/19.
//  Copyright © 2019 Zayid Oyelami. All rights reserved.
//

import IntentsUI
import Foundation
import Alamofire
import SwiftyJSON
import CoreMedia


// As an example, this extension's Info.plist has been configured to handle interactions for INSendMessageIntent.
// You will want to replace this or add other intents as appropriate.
// The intents whose interactions you wish to handle must be declared in the extension's Info.plist.

// You can test this example integration by saying things to Siri like:
// "Send a message using <myApp>"

class IntentViewController: UIViewController, INUIHostedViewControlling, INUIHostedViewSiriProviding  {
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var questionLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    // MARK: - INUIHostedViewControlling
    
    // Prepare your view controller for the interaction to handle.
    func configure(with interaction: INInteraction!, context: INUIHostedViewContext, completion: ((CGSize) -> Void)!) {
        // Do configuration here, including preparing views and calculating a desired size for presentation.
        
        let intent = interaction.intent as! INSendMessageIntent
        if let question = intent.content {
            questionLabel.text = question
            processRequest(text: question, textView:textView)
        if let completion = completion {
            completion(self.desiredSize)
        }
        }
    }
    
    var desiredSize: CGSize {
        return self.extensionContext!.hostedViewMaximumAllowedSize
    }
    
//    Displays my custom message UI

    var displaysMessage: Bool {
        return true
    }
}
//    // MARK: - INUIHostedViewControlling
//
//    // Prepare your view controller for the interaction to handle.
//    func configureView(for parameters: Set<INParameter>, of interaction: INInteraction, interactiveBehavior: INUIInteractiveBehavior, context: INUIHostedViewContext, completion: @escaping (Bool, Set<INParameter>, CGSize) -> Void) {
//        // Do configuration here, including preparing views and calculating a desired size for presentation.
//        guard let intent = interaction.intent as? INSendMessageIntent,
//        let questionString = intent.content
//            else {
//            completion(true, parameters, self.desiredSize)
//                return
//        }
//
//    var desiredSize: CGSize {
//        return self.extensionContext!.hostedViewMaximumAllowedSize
//    }
//
//}
private extension Dictionary {
    func percentEscaped() -> String {
        return map { (key, value) in
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedKey + "=" + escapedValue
            }
            .joined(separator: "&")
    }
}

private extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
        let subDelimitersToEncode = "!$&'()*+,;="

        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowed
    }()
}
private extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return NSAttributedString()
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
}

public func processRequest(text: String, textView:UITextView){
    let txt = text
    let parameters: [String: Any] = ["inquiry": txt ]
    let url  = URL(string: "https://api-concierge.aisoftware.com/v1/process")
    var request = URLRequest(url: url!)
    request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer 277b15da-ebd8-465f-a704-ab2128f58c4b", forHTTPHeaderField: "Authorization")
    request.httpMethod = "POST"
    request.httpBody = parameters.percentEscaped().data(using: .utf8)
    //create the session object
    let session = URLSession.shared
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("application/json", forHTTPHeaderField: "Accept")
    //create dataTask using the session object to send data to the server
    // Send button activity animation
    
    let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
        
        guard let data = data,
            let response = response as? HTTPURLResponse,
            error == nil else {                                              // check for fundamental networking error
                print("error", error ?? "Unknown error")
                return
        }
        
        guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
            print("statusCode should be 2xx, but is \(response.statusCode)")
            print("response = \(response)")
            return
        }
        
        // Need to convert to Json
        
        let json = try? JSON(data: data)
        var resp = json!["data"]["data"]["outputs"][0][0]
        
        DispatchQueue.main.async {
            let capacityResp = (resp.string?.htmlToAttributedString?.string)
            if var txtFromView = textView.text {
                txtFromView = capacityResp ?? ""
            }
        }
    })
    task.resume()
    
}
